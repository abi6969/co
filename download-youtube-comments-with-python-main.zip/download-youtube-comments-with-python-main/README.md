# download-youtube-comments-with-python
Download Youtube Comments With Python

With this fuction, you will only have to replace two things: replace the IPI key and the video id.
Once you do that, you can run the fuction and the CSV file will be located in the same folder as the python script.

Here is a link to the youtube video if don't know how how to get the API key.
https://youtu.be/B9uCX2s7y7A
